package com.example.onlinestore

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.firebase.auth.FirebaseAuth

class MainActivity : AppCompatActivity() {

    private lateinit var bottomNavigation: BottomNavigationView
    private lateinit var btnLogout: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Referencias a views
        bottomNavigation = findViewById(R.id.bottomNavigation)
        btnLogout = findViewById(R.id.btnLogout)

        // ------------------------
        //  BOTÓN CERRAR SESIÓN
        // ------------------------
        btnLogout.setOnClickListener {
            cerrarSesion()
        }

        // ------------------------
        //  BOTÓNES DEL BOTTOM NAV
        // ------------------------
        bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_productos -> {
                    cambiarFragment(ProductosFragment())
                    true
                }
                R.id.nav_carrito -> {
                    cambiarFragment(CarritoFragment())
                    true
                }
                R.id.nav_qr -> {
                    cambiarFragment(QRFragment())
                    true
                }
                R.id.nav_ubicacion -> {
                    cambiarFragment(UbicacionFragment())
                    true
                }
                else -> false
            }
        }

        // Cargar fragment inicial si es primera vez
        if (savedInstanceState == null) {
            cambiarFragment(ProductosFragment())
            bottomNavigation.selectedItemId = R.id.nav_productos
        }
    }

    // ------------------------
    //   CAMBIAR FRAGMENT
    // ------------------------
    private fun cambiarFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, fragment)
            .commit()
    }

    fun selectProductosTab() {
        bottomNavigation.selectedItemId = R.id.nav_productos
    }

    // ------------------------
    //   OPCIONES DE MENÚ (NO NECESARIO SI USAS BOTÓN)
    // ------------------------
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.menu_logout -> {
                cerrarSesion()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    // ------------------------
    //     CERRAR SESIÓN
    // ------------------------
    private fun cerrarSesion() {
        // 1. Logout real de Firebase
        FirebaseAuth.getInstance().signOut()

        // 2. Borrar preferencias locales (opcional)
        val sharedPreferences = getSharedPreferences("LoginPrefs", MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.putBoolean("isLoggedIn", false)
        editor.remove("usuario")
        editor.apply()

        // 3. Redirigir al Login
        val intent = Intent(this, LoginActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }
}
