package com.example.onlinestore

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthProvider

class VerifyCodeActivity : AppCompatActivity() {

    private lateinit var edtCodigo: EditText
    private lateinit var btnVerificar: Button
    private lateinit var auth: FirebaseAuth
    private lateinit var verificationId: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_verify_code)

        auth = FirebaseAuth.getInstance()

        edtCodigo = findViewById(R.id.edtCodigo)
        btnVerificar = findViewById(R.id.btnVerificar)

        // Recibir ID de verificación
        verificationId = intent.getStringExtra("verificationId") ?: ""

        btnVerificar.setOnClickListener {
            val code = edtCodigo.text.toString().trim()
            if (code.isEmpty()) {
                Toast.makeText(this, "Ingresa el código", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val credential = PhoneAuthProvider.getCredential(verificationId, code)
            signIn(credential)
        }
    }

    private fun signIn(credential: PhoneAuthCredential) {
        auth.signInWithCredential(credential)
            .addOnSuccessListener {
                Toast.makeText(this, "Verificación exitosa", Toast.LENGTH_SHORT).show()
                startActivity(Intent(this, MainActivity::class.java))
                finish()
            }
            .addOnFailureListener {
                Toast.makeText(this, "Error: ${it.message}", Toast.LENGTH_LONG).show()
            }
    }
}
