package com.example.onlinestore

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import com.google.android.material.textfield.TextInputEditText
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.FirebaseException
import com.google.firebase.auth.*
import java.util.concurrent.TimeUnit
import android.widget.TextView

class LoginActivity : AppCompatActivity() {

    private lateinit var edtUsuario: TextInputEditText
    private lateinit var edtPassword: TextInputEditText
    private lateinit var btnLogin: Button
    private lateinit var auth: FirebaseAuth

    // Variables para login por teléfono
    private lateinit var storedVerificationId: String
    private lateinit var resendToken: PhoneAuthProvider.ForceResendingToken

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)


        auth = FirebaseAuth.getInstance()

        // Si ya está logueado → redirigir
        if (auth.currentUser != null) {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            return
        }
        val txtCrearCuenta = findViewById<TextView>(R.id.txtCrearCuenta)
        txtCrearCuenta.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }


        edtUsuario = findViewById(R.id.edtUsuario)
        edtPassword = findViewById(R.id.edtPassword)
        btnLogin = findViewById(R.id.btnLogin)

        btnLogin.setOnClickListener {
            val usuario = edtUsuario.text.toString().trim()
            val password = edtPassword.text.toString().trim()

            if (usuario.isEmpty()) {
                edtUsuario.error = "Ingresa tu correo o teléfono"
                return@setOnClickListener
            }

            // Si escribe números → se asume login por teléfono
            if (usuario.matches(Regex("^[0-9+]+$"))) {
                loginTelefono(usuario)
            } else {
                loginEmail(usuario, password)
            }
        }
    }

    // ---------------------- LOGIN EMAIL ----------------------
    private fun loginEmail(email: String, password: String) {
        if (password.length < 6) {
            edtPassword.error = "La contraseña debe tener mínimo 6 caracteres"
            return
        }

        auth.signInWithEmailAndPassword(email, password)
            .addOnSuccessListener {
                Toast.makeText(this, "Bienvenido", Toast.LENGTH_SHORT).show()
                startActivity(Intent(this, MainActivity::class.java))
                finish()
            }
            .addOnFailureListener {
                Toast.makeText(this, "Error: ${it.message}", Toast.LENGTH_LONG).show()
            }
    }

    // ---------------------- LOGIN TELÉFONO ----------------------
    private fun loginTelefono(numero: String) {

        val options = PhoneAuthOptions.newBuilder(auth)
            .setPhoneNumber("+57$numero")   // 🇨🇴 Colombia (si deseas otro país, lo cambiamos)
            .setTimeout(60L, TimeUnit.SECONDS)
            .setActivity(this)
            .setCallbacks(object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {

                override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                    // Login automático si Google detecta el SMS
                    signInWithPhoneAuthCredential(credential)
                }

                override fun onVerificationFailed(e: FirebaseException) {
                    Toast.makeText(this@LoginActivity, "Error: ${e.message}", Toast.LENGTH_LONG)
                        .show()
                }

                override fun onCodeSent(
                    verificationId: String,
                    token: PhoneAuthProvider.ForceResendingToken
                ) {
                    storedVerificationId = verificationId
                    resendToken = token

                    // Enviar a pantalla de código (te la hago si la quieres)
                    val intent = Intent(this@LoginActivity, VerifyCodeActivity::class.java)
                    intent.putExtra("verificationId", verificationId)
                    startActivity(intent)
                }

            }).build()

        PhoneAuthProvider.verifyPhoneNumber(options)
    }

    private fun signInWithPhoneAuthCredential(credential: PhoneAuthCredential) {
        auth.signInWithCredential(credential)
            .addOnSuccessListener {
                Toast.makeText(this, "Acceso exitoso", Toast.LENGTH_SHORT).show()
                startActivity(Intent(this, MainActivity::class.java))
                finish()
            }
            .addOnFailureListener {
                Toast.makeText(this, "Error: ${it.message}", Toast.LENGTH_LONG).show()
            }
    }
}
